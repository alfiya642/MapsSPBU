package com.example.mapsspbu;

import androidx.fragment.app.FragmentActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-6.809829, 111.830028);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        LatLng KandangMargosuko = new LatLng( -6.792846, 111.801948);
        mMap.addMarker(new MarkerOptions().position(KandangMargosuko).title("spbu kandang"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(KandangMargosuko));

        mMap.addPolyline(new PolylineOptions().add(
                sydney,
                new LatLng(-6.809791, 111.829751),
                new LatLng(-6.810124, 111.829625),
                new LatLng(-6.810683, 111.829445),
                new LatLng(-6.810817, 111.829974),
                new LatLng(-6.811360, 111.830441),
                new LatLng(-6.809536, 111.831391),
                new LatLng(-6.809173, 111.831748),
                new LatLng(-6.806438, 111.832629),
                new LatLng(-6.803875, 111.833534),
                new LatLng(-6.802150, 111.833740),
                new LatLng(-6.801571, 111.830035),
                new LatLng(-6.800497, 111.825674),
                new LatLng(-6.800461, 111.825200),
                new LatLng(-6.800220, 111.824253),
                new LatLng(-6.799918, 111.823658),
                new LatLng(-6.799044, 111.820250),
                new LatLng(-6.797898, 111.815531),
                new LatLng(-6.796342, 111.811243),
                new LatLng(-6.794267, 111.806214),
                new LatLng(-6.792494, 111.802011),
                KandangMargosuko


                )
                        .width(10)
                        .color(Color.BLUE)
        );



        LatLng KandangMargosuko1 = new LatLng( -6.792846, 111.801948);
        mMap.addMarker(new MarkerOptions().position(KandangMargosuko1).title("spbu kandang"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(KandangMargosuko1));

        LatLng boncong = new LatLng( -6.773591, 111.747635);
        mMap.addMarker(new MarkerOptions().position(boncong).title("spbu boncong"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(boncong));

        mMap.addPolyline(new PolylineOptions().add(
                KandangMargosuko1,
                new LatLng(-6.792494, 111.802011),
                new LatLng(-6.784863, 111.785056),
                new LatLng(-6.783840, 111.782695),
                new LatLng(-6.783702, 111.782556),
                new LatLng(-6.783339, 111.781558),
                new LatLng(-6.782668, 111.778570),
                new LatLng(-6.782178, 111.775137),
                new LatLng(-6.781805, 111.773420),
                new LatLng(-6.780772, 111.770921),
                new LatLng(-6.779696, 111.767230),
                new LatLng(-6.779142, 111.764322),
                new LatLng(-6.779152, 111.763367),
                new LatLng(-6.779163, 111.761704),
                new LatLng(-6.778620, 111.759344),
                new LatLng(-6.778066, 111.757874),
                new LatLng(-6.776596, 111.754055),
                new LatLng(-6.774870, 111.751566),
                new LatLng(-6.774348, 111.750428),
                new LatLng(-6.773644, 111.748068),

                boncong


                )
                        .width(10)
                        .color(Color.BLUE)
        );

        LatLng boncong1 = new LatLng( -6.773591, 111.747635);
        mMap.addMarker(new MarkerOptions().position(boncong1).title("spbu boncong"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(boncong1));

        LatLng sukolilo = new LatLng( -6.766289, 111.709511);
        mMap.addMarker(new MarkerOptions().position(sukolilo).title("spbu sukolilo"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sukolilo));
        mMap.addPolyline(new PolylineOptions().add(
                boncong1,

                new LatLng(-6.773644, 111.748068),
                new LatLng(-6.773067, 111.746970),
                new LatLng(-6.772459, 111.745854),
                new LatLng(-6.772140, 111.744535),
                new LatLng(-6.771767, 111.742142),
                new LatLng(-6.772353, 111.737604),
                new LatLng(-6.771959, 111.735040),
                new LatLng(-6.771857, 111.733119),
                new LatLng(-6.771783, 111.729879),
                new LatLng(-6.771639, 111.727299),
                new LatLng(-6.771639, 111.727299),
                new LatLng(-6.770925, 111.722519),
                new LatLng(-6.770728, 111.721317),
                new LatLng(-6.770384, 111.719786),
                new LatLng(-6.769532, 111.717739),
                new LatLng(-6.768861, 111.715883),
                new LatLng(-6.768150, 111.714043),
                new LatLng(-6.767228, 111.711621),
                new LatLng(-6.766149, 111.709569),
                sukolilo

                )
                        .width(10)
                        .color(Color.BLUE)
        );


        LatLng sukolilo1 = new LatLng( -6.766289, 111.709511);
        mMap.addMarker(new MarkerOptions().position(sukolilo1).title("spbu sukolilo"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sukolilo1));

        LatLng perbatasan = new LatLng( -6.757718, 111.695663);
        mMap.addMarker(new MarkerOptions().position(perbatasan).title("spbu perbatasan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(perbatasan));

        mMap.addPolyline(new PolylineOptions().add(
                sukolilo1,
                new LatLng(-6.766149, 111.709569),
                new LatLng(-6.765172, 111.707804),
                new LatLng(-6.764213, 111.706107),
                new LatLng(-6.763403, 111.704615),
                new LatLng(-6.762476, 111.703145),
                new LatLng(-6.761363, 111.701552),
                new LatLng(-6.759919, 111.699390),
                new LatLng(-6.759142, 111.698149),
                new LatLng(-6.758034, 111.695788),

                perbatasan

                )
                        .width(10)
                        .color(Color.BLUE)
        );

    }
}

